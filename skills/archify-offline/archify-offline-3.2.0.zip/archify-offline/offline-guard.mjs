import net from 'node:net';
import dgram from 'node:dgram';
import { syncBuiltinESMExports } from 'node:module';

// Only local IPC and explicit loopback TCP are allowed in the Node process.
const originalConnect = net.Socket.prototype.connect;
const localNames = new Set(['localhost', '127.0.0.1', '::1', '[::1]']);
net.Socket.prototype.connect = function (...args) {
  const normalized = Array.isArray(args[0]) ? args[0] : args;
  const first = normalized[0];
  let host = 'localhost';
  if (first && typeof first === 'object') {
    if (typeof first.path === 'string') {
      const localPipe = process.platform === 'win32' ? first.path.startsWith('\\\\.\\pipe\\') : (first.path.startsWith('/') && !first.path.startsWith('//'));
      if (!localPipe) throw new Error('Archify offline: remote socket paths are disabled');
      return originalConnect.apply(this, args);
    }
    host = first.host || first.hostname || 'localhost';
  } else if (typeof first === 'string' && !/^\d+$/.test(first)) {
    if (process.platform === 'win32' ? first.startsWith('\\\\.\\pipe\\') : (first.startsWith('/') && !first.startsWith('//'))) return originalConnect.apply(this, args);
    throw new Error('Archify offline: unverified socket path is disabled');
  } else if (typeof normalized[1] === 'string') {
    host = normalized[1];
  }
  if (!localNames.has(String(host).toLowerCase())) {
    throw new Error('Archify offline: outbound network connections are disabled');
  }
  return originalConnect.apply(this, args);
};
dgram.createSocket = function () { throw new Error('Archify offline: UDP networking is disabled'); };
globalThis.fetch = async function () { throw new Error('Archify offline: fetch is disabled'); };
syncBuiltinESMExports();
